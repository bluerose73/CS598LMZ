# Copyright © 2023 Apple Inc.

"""Tests SpmdTrainer."""
# pylint: disable=no-self-use
import copy
import dataclasses
import os.path
import shutil
import tempfile
import unittest
from typing import Any, Callable, Dict, Literal, Optional, Sequence

import chex
import jax
import jax.random
import numpy as np
import tensorflow as tf
from absl import flags, logging
from absl.testing import absltest, parameterized
from jax import numpy as jnp

from axlearn.common import layers, learner, optimizers, param_init, struct_test, test_utils
from axlearn.common.base_layer import NestedParameterSpec, ParameterSpec
from axlearn.common.base_model import BaseModel
from axlearn.common.checkpointer import (
    Checkpointer,
    CheckpointPolicy,
    every_n_steps_and_last_policy,
    every_n_steps_policy,
)
from axlearn.common.config import REQUIRED, Required, config_class, config_for_function
from axlearn.common.evaler import SpmdEvaler
from axlearn.common.evaler import every_n_steps_policy as eval_every_n_steps_policy
from axlearn.common.learner import UpdateType, should_update_with_optimizers
from axlearn.common.module import Module
from axlearn.common.state_builder import Builder as TrainerStateBuilder
from axlearn.common.trainer import SpmdTrainer, TrainerState, select_mesh_config
from axlearn.common.utils import NestedTensor, Tensor, as_tensor, flatten_items, match_regex_rules

FLAGS = flags.FLAGS

NUM_CLASSES = 16


class DummyInput(Module):
    """A dummy input."""

    @config_class
    class Config(Module.Config):
        """Configures DummyInput."""

        is_training: Required[bool] = REQUIRED
        batch_size: int = 8  # The batch size.
        total_num_batches: Optional[int] = None  # The total number of batches. If None, unlimited.
        include_labels: bool = True

    def __init__(self, cfg: Config, *, parent=None):
        super().__init__(cfg, parent=parent)
        cfg = self.config
        if cfg.is_training != (cfg.total_num_batches is None):
            raise ValueError("total_num_batches should be None iff is_training")
        self._tmp_dir = tempfile.mkdtemp()
        self._record_file = self._write_records(self._tmp_dir)

    def __del__(self):
        shutil.rmtree(self._tmp_dir)

    def _write_records(self, tmp_dir) -> str:
        """Writes records to `tmp_dir` and returns the filename."""
        cfg: DummyInput.Config = self.config
        filename = os.path.join(tmp_dir, "records")
        with tf.io.TFRecordWriter(filename) as file_writer:
            for batch in self._datagen(cfg.total_num_batches or 5):
                feature_dict = {
                    "image": tf.train.Feature(
                        float_list=tf.train.FloatList(value=batch["image"].reshape([-1]).tolist())
                    ),
                }
                if "label" in batch:
                    feature_dict["label"] = tf.train.Feature(
                        int64_list=tf.train.Int64List(value=batch["label"].tolist())
                    )
                example = tf.train.Example(features=tf.train.Features(feature=feature_dict))
                file_writer.write(example.SerializeToString())
        return filename

    def _datagen(self, total_num_batches):
        cfg: DummyInput.Config = self.config
        num_batches = 0
        prng_key = jax.random.PRNGKey(1)

        while num_batches < total_num_batches:
            num_batches += 1
            prng_key, image_key, label_key = jax.random.split(prng_key, 3)
            batch = dict(
                image=jax.random.randint(
                    image_key,
                    shape=[cfg.batch_size, 224, 224, 3],
                    minval=0,
                    maxval=256,
                    dtype=np.int32,
                ).astype(np.float32),
            )
            if cfg.include_labels:
                batch["label"] = jax.random.randint(
                    label_key,
                    shape=[cfg.batch_size],
                    minval=0,
                    maxval=NUM_CLASSES,
                    dtype=np.int32,
                )
            yield batch

    def dataset(self) -> tf.data.Dataset:
        cfg = self.config
        features = {
            "image": tf.io.FixedLenFeature(shape=(cfg.batch_size, 224, 224, 3), dtype=tf.float32),
        }
        if cfg.include_labels:
            features["label"] = tf.io.FixedLenFeature(shape=(cfg.batch_size,), dtype=tf.int64)
        ds = tf.data.TFRecordDataset(filenames=[self._record_file]).map(
            lambda record_bytes: tf.io.parse_single_example(record_bytes, features=features)
        )
        if cfg.total_num_batches is None:
            ds = ds.repeat()
        return ds

    def __iter__(self):
        # Use a different __iter__ than iter(self.dataset()), to test that input iter can be
        # checkpointed properly even with a custom __iter__ (note that a custom __iter__ is not
        # guaranteed to be savable).
        for input_batch in self.dataset():
            yield input_batch


class DummyModel(BaseModel):
    """A dummy model."""

    @config_class
    class Config(BaseModel.Config):
        """Configures DummyModel."""

        # Whether to explicitly init dummy state to test pruning backwards compat.
        init_dummy_state: bool = False

    def __init__(self, cfg: Config, *, parent: Optional[Module]):
        super().__init__(cfg, parent=parent)
        cfg = self.config
        self._add_child(
            "fc",
            layers.Linear.default_config().set(
                input_dim=3,
                output_dim=NUM_CLASSES,
                bias=True,
                param_partition_spec=(None, "model"),
            ),
        )
        self.predict_dtypes = []

    def create_parameter_specs_recursively(self) -> NestedParameterSpec:
        specs = super().create_parameter_specs_recursively()
        if self.config.init_dummy_state:
            specs["dummy"] = {"nested": {"empty": {}}}  # type: ignore
        return dict(sorted(specs.items()))  # type: ignore

    def initialize_parameters_recursively(
        self, prng_key: Tensor, *, prebuilt: Optional[NestedTensor]
    ) -> NestedTensor:
        params = super().initialize_parameters_recursively(prng_key, prebuilt=prebuilt)
        if self.config.init_dummy_state:
            params["dummy"] = {"nested": {"empty": {}}}
        return params

    # We drop the kwargs from BaseModel, since they aren't used here.
    # pylint: disable-next=arguments-differ
    def forward(self, input_batch: NestedTensor):
        self.add_state_update(
            "dummy",
            {
                "nested": {
                    "empty": {},
                },
            },
        )

        # [batch, 3].
        logits = self.predict(input_batch)
        label: Tensor = input_batch["label"]
        loss = (
            -(jax.nn.log_softmax(logits) * jax.nn.one_hot(label, NUM_CLASSES, dtype=logits.dtype))
            .sum(axis=-1)
            .mean()
        )
        return loss, {"prng_key": self.prng_key}

    def predict(self, input_batch: NestedTensor) -> Tensor:
        image = input_batch["image"]
        self.predict_dtypes.append(image.dtype)
        hidden = image.mean(axis=(1, 2))
        return self.fc(hidden)


class NonPartitionedModel(BaseModel):
    """A dummy replicated model."""

    def __init__(self, cfg: BaseModel.Config, *, parent: Optional[Module]):
        super().__init__(cfg, parent=parent)
        self._add_child(
            "fc",
            layers.Linear.default_config().set(
                input_dim=3,
                output_dim=NUM_CLASSES,
                bias=True,
                param_partition_spec=(None, "model"),
            ),
        )

    def create_parameter_specs_recursively(self) -> NestedParameterSpec:
        return None

    # We drop the kwargs from BaseModel, since they aren't used here.
    # pylint: disable-next=arguments-differ
    def forward(self, input_batch: NestedTensor):
        # [batch, 3].
        logits = self.predict(input_batch)
        label: Tensor = input_batch["label"]
        loss = (
            -(jax.nn.log_softmax(logits) * jax.nn.one_hot(label, NUM_CLASSES, dtype=logits.dtype))
            .sum(axis=-1)
            .mean()
        )
        return loss, {"prng_key": self.prng_key}

    def predict(self, input_batch: NestedTensor) -> Tensor:
        image = input_batch["image"]
        hidden = image.mean(axis=(1, 2))
        return self.fc(hidden)


class DummyStateBuilder(TrainerStateBuilder):
    """A dummy builder that "builds" state from fixed values."""

    @config_class
    class Config(Module.Config):
        step: Required[int] = REQUIRED
        model_state: Required[Callable[[], NestedTensor]] = REQUIRED
        input_state_type: Required[TrainerStateBuilder.StateType] = REQUIRED

    def input_state_type(self) -> TrainerStateBuilder.StateType:
        return self.config.input_state_type

    def __call__(self, state: TrainerStateBuilder.State) -> TrainerStateBuilder.State:
        built_state = TrainerStateBuilder.State(
            step=state.step,
            trainer_state=state.trainer_state,
            built_keys=copy.deepcopy(state.built_keys),
        )
        built_keys = set(
            f"model/{key}" for key, _ in flatten_items(built_state.trainer_state.model)
        )
        logging.info("built_keys=%s", built_keys)
        return TrainerStateBuilder.State(
            step=self.config.step,
            trainer_state=TrainerState(
                prng_key=built_state.trainer_state.prng_key,
                model=self.config.model_state(),
                learner=built_state.trainer_state.learner,
            ),
            built_keys=built_keys,
        )


class TrainerTest(test_utils.TestCase):
    """Tests SpmdTrainer."""

    def _trainer_config(self):
        return SpmdTrainer.default_config().set(
            name="base_trainer",
            vlog=3,
            dir=tempfile.mkdtemp(),  # TODO(markblee): Use a context.
            mesh_axis_names=("data", "model"),
            mesh_shape=(1, 1),
            model=DummyModel.default_config().set(
                dtype=jnp.float32, param_init=param_init.DefaultInitializer.default_config()
            ),
            input=DummyInput.default_config(),
            learner=learner.Learner.default_config().set(
                optimizer=config_for_function(optimizers.sgd_optimizer).set(
                    learning_rate=0.1,
                    decouple_weight_decay=True,
                    momentum=0.9,
                    weight_decay=1e-4,
                ),
            ),
            max_step=6,
            checkpointer=Checkpointer.default_config().set(
                save_policy=config_for_function(every_n_steps_policy).set(n=5)
            ),
            evalers=dict(
                eval_dummy=SpmdEvaler.default_config().set(
                    input=DummyInput.default_config().set(total_num_batches=2),
                ),
            ),
        )

    # Previously there was a test for pruning backwards compatibility with no pruning here.
    # This has been removed as there appear to be no models in the source tree that
    # do not use pruning, and keeping this test required maintaining the `prune_empty_state_updates`
    # config option.

    # A similar test exists for evaler.
    # pylint: disable=duplicate-code
    @parameterized.parameters(
        {"platform": "cpu", "mesh_shape": (1, 1), "step_dtype": None},
        {"platform": "cpu", "mesh_shape": (1, 1), "step_dtype": jnp.bfloat16},
        {"platform": "cpu", "mesh_shape": (1, 1), "step_dtype": None, "ema_decay": 0.99},
        {"platform": "cpu", "mesh_shape": (1, 1), "step_dtype": None, "start_trace_steps": (1, 5)},
        {"platform": "tpu", "mesh_shape": (8, 1), "step_dtype": jnp.bfloat16},
        {"platform": "tpu", "mesh_shape": (2, 4), "step_dtype": jnp.float32},
    )
    # pylint: enable=duplicate-code
    def test_trainer(
        self,
        platform,
        mesh_shape,
        step_dtype,
        *,
        ema_decay=None,
        start_trace_steps=tuple(),
    ):
        if not test_utils.is_supported_platform(platform):
            return
        cfg = SpmdTrainer.default_config().set(name="test_trainer", train_dtype=step_dtype)
        cfg.dir = tempfile.mkdtemp()
        cfg.mesh_axis_names = ("data", "model")
        cfg.mesh_shape = mesh_shape
        cfg.model = DummyModel.default_config().set(dtype=jnp.float32)
        cfg.input = DummyInput.default_config()
        cfg.learner = learner.Learner.default_config().set(
            optimizer=config_for_function(optimizers.sgd_optimizer).set(
                learning_rate=0.1,
                decouple_weight_decay=True,
                momentum=0.9,
                weight_decay=1e-4,
            )
        )
        if ema_decay:
            cfg.learner.ema.decay = ema_decay
        if start_trace_steps:
            cfg.start_trace_steps = start_trace_steps
        evaler_cfg = SpmdEvaler.default_config().set(
            input=DummyInput.default_config().set(total_num_batches=2),
            eval_dtype=step_dtype,
        )
        evaler_cfg.summary_writer.vlog = 5
        cfg.evalers = dict(eval_dummy=evaler_cfg)
        cfg.checkpointer.save_policy = config_for_function(every_n_steps_policy).set(n=5)
        cfg.summary_writer.vlog = 5
        cfg.max_step = 12
        cfg.watchdog_timeout_seconds = 0.1
        cfg.vlog = 2
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        output_a = trainer.run(prng_key=jax.random.PRNGKey(123))
        if ema_decay is None:
            self.assertIs(trainer.model_params_for_eval(), trainer.trainer_state.model)
        else:
            self.assertIs(trainer.model_params_for_eval(), trainer.trainer_state.learner["ema"].ema)
        # Check we did the compute in step_dtype.
        self.assertEqual(output_a["loss"].dtype, step_dtype or cfg.model.dtype)
        # Check that we also did the eval step in step_dtype.
        self.assertEqual(
            len(
                [el for el in trainer.model.predict_dtypes if el == (step_dtype or cfg.model.dtype)]
            ),
            2,  # Once for the train step trace, once for the eval_step trace.
        )
        with open(os.path.join(cfg.dir, "trainer_state_tree.txt"), encoding="utf-8") as f:
            self.assertStartsWith(f.read(), "PyTreeDef(CustomNode(namedtuple[TrainerState], [*, ")

        if start_trace_steps:
            trace_dir = os.path.join(cfg.dir, "summaries", "train_train", "plugins", "profile")
            profile_files = []
            for root, unused_dirs, files in os.walk(trace_dir):
                for name in files:
                    profile_files.append(os.path.join(root, name))
            print(f"profile_files={profile_files}")
            self.assertNotEmpty(profile_files)

        trainer2: SpmdTrainer = cfg.instantiate(parent=None)
        with trainer2.mesh():
            self.assertEqual(10, trainer2.restore_checkpoint())

        # Re-create 'trainer'.
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        # Since we will be resuming from the checkpoint at step 10, a different prng_key doesn't
        # matter.
        output_b = trainer.run(prng_key=jax.random.PRNGKey(456))
        # Check we did the training compute in step_dtype.
        self.assertEqual(output_b["loss"].dtype, step_dtype or cfg.model.dtype)
        # Check that we also did the eval step in step_dtype.
        self.assertEqual(
            len(
                [el for el in trainer.model.predict_dtypes if el == (step_dtype or cfg.model.dtype)]
            ),
            2,  # Once for the train step trace, once for the eval_step trace.
        )
        # The prng_key per step is deterministic.
        np.testing.assert_array_equal(output_a["aux"]["prng_key"], output_b["aux"]["prng_key"])

    @parameterized.parameters(
        {"return_evaler_summaries": None},
        {"return_evaler_summaries": True},
        {"return_evaler_summaries": False},
        {"return_evaler_summaries": {"wrong"}},
        {"return_evaler_summaries": {"eval_dummy"}},
        {"return_evaler_summaries": {"eval_dummy", "eval_dummy2"}},
    )
    def test_return_evaler_summaries(self, return_evaler_summaries):
        step_dtype = None
        cfg = SpmdTrainer.default_config().set(
            name="test_return_evaler_summaries_trainer", train_dtype=step_dtype
        )
        cfg.dir = tempfile.mkdtemp()
        cfg.mesh_axis_names = ("data", "model")
        cfg.mesh_shape = (1, 1)
        cfg.model = DummyModel.default_config().set(dtype=jnp.float32)
        cfg.input = DummyInput.default_config()
        cfg.learner = learner.Learner.default_config().set(
            optimizer=config_for_function(optimizers.sgd_optimizer).set(
                learning_rate=0.1,
                decouple_weight_decay=True,
                momentum=0.9,
                weight_decay=1e-4,
            )
        )
        evaler_cfg = SpmdEvaler.default_config().set(
            input=DummyInput.default_config().set(total_num_batches=2),
            eval_dtype=step_dtype,
            eval_policy=config_for_function(eval_every_n_steps_policy).set(n=10),
        )
        evaler_cfg.summary_writer.vlog = 5
        cfg.evalers = dict(eval_dummy=evaler_cfg, eval_dummy2=evaler_cfg.clone())
        cfg.checkpointer.save_policy = config_for_function(every_n_steps_policy).set(n=5)
        cfg.summary_writer.vlog = 5
        cfg.max_step = 3
        cfg.watchdog_timeout_seconds = 0.1
        cfg.vlog = 2
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        # Check exception when return_evaler_summaries contains names that don't match evalers.
        if isinstance(return_evaler_summaries, set) and "wrong" in return_evaler_summaries:
            with self.assertRaises(ValueError):
                trainer.run(
                    prng_key=jax.random.PRNGKey(123),
                    return_evaler_summaries=return_evaler_summaries,
                )
            return
        else:
            output = trainer.run(
                prng_key=jax.random.PRNGKey(123), return_evaler_summaries=return_evaler_summaries
            )
        if return_evaler_summaries is None or return_evaler_summaries is False:
            self.assertTrue("evaler_summaries" not in output)
        else:
            self.assertTrue("evaler_summaries" in output)
            # evalers not force run will have None as value in evaler_summaries.
            if return_evaler_summaries is True:
                expected_non_empty_keys = {"eval_dummy", "eval_dummy2"}
            elif isinstance(return_evaler_summaries, set):
                expected_non_empty_keys = return_evaler_summaries
            else:
                raise ValueError(
                    f"return_evaler_summaries {return_evaler_summaries} not supported!"
                )
            self.assertTrue(
                expected_non_empty_keys
                == set(k for k, v in output["evaler_summaries"].items() if v is not None)
            )

    def test_stop_on_exception(self):
        """Test that trainer exits cleanly if there's an exception in the main loop."""
        if not test_utils.is_supported_platform("cpu"):
            return

        class RaiseInput(DummyInput):
            """A dummy input that raises an exception after N batches."""

            @config_class
            class Config(DummyInput.Config):
                raise_on_batch: Required[int] = REQUIRED

            def dataset(self):
                cfg = self.config
                for input_batch in super().dataset().take(cfg.raise_on_batch - 1):
                    yield input_batch
                raise ValueError(f"Raising on batch {cfg.raise_on_batch}")

        cfg = self._trainer_config().set(max_step=3, watchdog_timeout_seconds=10)
        cfg.input = RaiseInput.default_config().set(raise_on_batch=cfg.max_step - 1)
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        with self.assertRaisesRegex(ValueError, f"Raising on batch {cfg.input.raise_on_batch}"):
            trainer.run(prng_key=jax.random.PRNGKey(123))
        # pylint: disable=protected-access
        self.assertTrue(trainer._watchdog_stopping.is_set())
        self.assertIsNone(trainer._watchdog_thread)
        # pylint: enable=protected-access

    def test_non_partitioned_model(self):
        if jax.default_backend() != "cpu":
            return
        cfg = SpmdTrainer.default_config().set(name="test_trainer")
        cfg.dir = tempfile.mkdtemp()
        cfg.mesh_axis_names = ("data", "model")
        cfg.mesh_shape = (1, 1)
        cfg.model = NonPartitionedModel.default_config().set(
            dtype=jnp.float32, param_init=param_init.DefaultInitializer.default_config()
        )
        cfg.input = DummyInput.default_config()
        cfg.learner = learner.Learner.default_config().set(
            optimizer=config_for_function(optimizers.sgd_optimizer).set(
                learning_rate=0.1,
                decouple_weight_decay=True,
                momentum=0.9,
                weight_decay=1e-4,
            )
        )
        cfg.evalers = dict(
            eval_dummy=SpmdEvaler.default_config().set(
                input=DummyInput.default_config().set(total_num_batches=2),
            )
        )
        cfg.checkpointer.save_policy = config_for_function(every_n_steps_policy).set(n=5)
        cfg.max_step = 12
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        trainer.run(prng_key=jax.random.PRNGKey(123))

    @parameterized.parameters(
        TrainerStateBuilder.StateType.TENSORS,
        TrainerStateBuilder.StateType.TENSOR_SPECS,
    )
    def test_restore_from_builder(self, builder_input_state_type):
        cfg = SpmdTrainer.default_config().set(
            name="test_trainer",
            dir=tempfile.mkdtemp(),
            mesh_axis_names=("data", "model"),
            mesh_shape=(1, 1),
            model=DummyModel.default_config().set(dtype=jnp.float32),
            input=DummyInput.default_config(),
            learner=learner.Learner.default_config().set(
                optimizer=config_for_function(optimizers.sgd_optimizer).set(
                    learning_rate=0.1,
                    decouple_weight_decay=True,
                    momentum=0.9,
                    weight_decay=1e-4,
                ),
            ),
            max_step=12,
            checkpointer=Checkpointer.default_config().set(
                save_policy=config_for_function(every_n_steps_policy).set(n=5),
            ),
            evalers=dict(
                eval_dummy=SpmdEvaler.default_config().set(
                    input=DummyInput.default_config().set(total_num_batches=2),
                ),
            ),
        )
        # Construct a dummy builder that loads some pre-determined state.
        new_model_state = (
            cfg.model.clone(name="test_model")
            .instantiate(parent=None)
            .initialize_parameters_recursively(jax.random.PRNGKey(4321), prebuilt=None)
        )
        new_model_state = as_tensor(new_model_state)
        state_builder = DummyStateBuilder.default_config().set(
            step=100,
            model_state=lambda: new_model_state,
            input_state_type=builder_input_state_type,
        )

        # Init without builder.
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        trainer.init(jax.random.PRNGKey(0))
        # Sanity check that the initial model state is not already equal.
        with self.assertRaises(AssertionError):
            # pylint: disable-next=protected-access
            self.assertNestedAllClose(trainer._trainer_state.model, new_model_state)

        # Restore from builder, and check model state and step are now updated.
        cfg.set(init_state_builder=state_builder)
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        trainer.init(jax.random.PRNGKey(0))
        # pylint: disable-next=protected-access
        self.assertNestedAllClose(trainer._trainer_state.model, new_model_state)
        self.assertEqual(trainer.step, state_builder.step)

    @parameterized.named_parameters(
        ("default", []),
        ("skip_bias", [(".*/bias$", UpdateType.NO_UPDATE)]),
        ("skip_all", [(".*", UpdateType.NO_UPDATE)]),
    )
    def test_should_compute_gradients(self, update_rules):
        cfg = SpmdTrainer.default_config().set(name="test_trainer")
        cfg.mesh_axis_names = ("data", "model")
        cfg.mesh_shape = (1, 1)
        cfg.dir = tempfile.mkdtemp()
        cfg.model = DummyModel.default_config().set(dtype=jnp.float32)
        cfg.input = DummyInput.default_config()
        cfg.learner = learner.Learner.default_config().set(
            optimizer=config_for_function(optimizers.sgd_optimizer).set(
                learning_rate=0.1,
                decouple_weight_decay=True,
                momentum=0.9,
                weight_decay=0,
            ),
            update_rules=update_rules,
        )
        evaler_cfg = SpmdEvaler.default_config().set(
            input=DummyInput.default_config().set(total_num_batches=2),
        )
        evaler_cfg.summary_writer.vlog = 5
        cfg.evalers = dict(eval_dummy=evaler_cfg)
        cfg.checkpointer.save_policy = config_for_function(every_n_steps_policy).set(n=5)
        cfg.summary_writer.vlog = 5
        cfg.max_step = 12
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        with trainer.mesh():
            trainer.init(prng_key=jax.random.PRNGKey(123))
            init_params = trainer.trainer_state.model
            trainer.run(prng_key=jax.random.PRNGKey(123))
            updated_params = trainer.trainer_state.model
            for (path, init_p), (_, updated_p) in zip(
                flatten_items(init_params), flatten_items(updated_params)
            ):
                if should_update_with_optimizers(
                    match_regex_rules(
                        path, rules=update_rules, default_value=UpdateType.ALL_UPDATES
                    )
                ):
                    self.assertGreater(np.max(np.abs(updated_p - init_p)), 1e-3, msg=path)
                else:
                    np.testing.assert_allclose(init_p, updated_p, err_msg=path)

    @parameterized.parameters(True, False)
    def test_run_builder(self, restore_from_builder: bool):
        model_cfg = DummyModel.default_config().set(dtype=jnp.float32)
        cfg = SpmdTrainer.default_config().set(
            name="test_trainer",
            dir=tempfile.mkdtemp(),
            mesh_axis_names=("data", "model"),
            mesh_shape=(1, 1),
            model=model_cfg,
            input=DummyInput.default_config(),
            learner=learner.Learner.default_config().set(
                optimizer=config_for_function(optimizers.sgd_optimizer).set(
                    learning_rate=0.1,
                    decouple_weight_decay=True,
                    momentum=0.9,
                    weight_decay=1e-4,
                ),
            ),
            max_step=0,
            checkpointer=Checkpointer.default_config().set(
                save_policy=config_for_function(every_n_steps_policy).set(n=5),
            ),
            evalers=dict(
                eval_dummy=SpmdEvaler.default_config().set(
                    input=DummyInput.default_config().set(total_num_batches=2),
                ),
            ),
        )
        if restore_from_builder:
            cfg.set(
                init_state_builder=DummyStateBuilder.default_config().set(
                    step=0,
                    model_state=lambda: (
                        model_cfg.clone(name="test_model")
                        .instantiate(parent=None)
                        .initialize_parameters_recursively(jax.random.PRNGKey(4321), prebuilt=None)
                    ),
                    input_state_type=TrainerStateBuilder.StateType.TENSOR_SPECS,
                ),
            )
            # Initial run should load from builder, if provided.
            trainer: SpmdTrainer = cfg.set(max_step=0).instantiate(parent=None)
            trainer.run(prng_key=jax.random.PRNGKey(123))

            # Validate that the initial state is as expected.
            self.assertNestedAllClose(
                trainer.trainer_state.model, cfg.init_state_builder.model_state()
            )

        # Run until first checkpoint.
        trainer: SpmdTrainer = cfg.set(max_step=6).instantiate(parent=None)
        first_output = trainer.run(prng_key=jax.random.PRNGKey(123))

        assert os.path.exists(os.path.join(cfg.dir, "trainer_state_tree.txt"))
        # Make sure checkpoint exists.
        trainer2: SpmdTrainer = cfg.instantiate(parent=None)
        with trainer2.mesh():
            self.assertEqual(5, trainer2.restore_checkpoint())

        # Once checkpoint is reached, next run should read from checkpoint, not builder.
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        second_output = trainer.run(prng_key=jax.random.PRNGKey(456))

        # Make sure the final state matches expected step and PRNGKey from first run.
        self.assertEqual(trainer.step, cfg.max_step)
        self.assertNestedAllClose(first_output["aux"], second_output["aux"])

    @parameterized.product(
        save_input_iterator=[False, True],
        restore_input_iterator=[False, True],
    )
    def test_checkpoint_policy(self, *, save_input_iterator: bool, restore_input_iterator: bool):
        """Test checkpoint policy when evaler and checkpointer run at different cadences."""
        model_cfg = DummyModel.default_config().set(dtype=jnp.float32)

        def checkpoint_if_all_evalers_run(evaler_names: Sequence[str]) -> CheckpointPolicy:
            def fn(*, step: int, evaler_summaries: Dict[str, Any]):
                del step
                for evaler_name in evaler_names:
                    if evaler_summaries.get(evaler_name) is None:
                        return False
                return True

            return fn

        cfg = SpmdTrainer.default_config().set(
            name="test_trainer",
            dir=tempfile.mkdtemp(),
            mesh_axis_names=("data", "model"),
            mesh_shape=(1, 1),
            model=model_cfg,
            input=DummyInput.default_config(),
            learner=learner.Learner.default_config().set(
                optimizer=config_for_function(optimizers.sgd_optimizer).set(
                    learning_rate=0.1, decouple_weight_decay=True
                ),
            ),
            max_step=8,
            checkpointer=Checkpointer.default_config().set(
                save_policy=config_for_function(checkpoint_if_all_evalers_run).set(
                    evaler_names=["eval_every_2", "eval_every_3"]
                ),
            ),
            evalers=dict(
                eval_every_2=SpmdEvaler.default_config().set(
                    input=DummyInput.default_config().set(total_num_batches=1),
                    eval_policy=config_for_function(eval_every_n_steps_policy).set(n=2),
                ),
                eval_every_3=SpmdEvaler.default_config().set(
                    input=DummyInput.default_config().set(total_num_batches=2),
                    eval_policy=config_for_function(eval_every_n_steps_policy).set(n=3),
                ),
            ),
            save_input_iterator=save_input_iterator,
        )

        # Run trainer.
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        trainer.run(prng_key=jax.random.PRNGKey(123))

        assert os.path.exists(os.path.join(cfg.dir, "trainer_state_tree.txt"))
        trainer2: SpmdTrainer = cfg.clone(save_input_iterator=restore_input_iterator).instantiate(
            parent=None
        )
        with trainer2.mesh():
            # We should have checkpointed at step 6, when all evalers ran.
            #
            # Note that we expect `restore_checkpoint` to succeed even if
            # `save_input_iterator` != `restore_input_iterator`, # so that users can turn on/off
            # `save_input_iterator` for models without breaking backwards compatibility.
            self.assertEqual(6, trainer2.restore_checkpoint())

    def test_last_step_checkpoint_policy(self):
        """Test checkpoint policy saving at the last step."""
        model_cfg = DummyModel.default_config().set(dtype=jnp.float32)

        cfg = SpmdTrainer.default_config().set(
            name="test_trainer",
            dir=tempfile.mkdtemp(),
            mesh_axis_names=("data", "model"),
            mesh_shape=(1, 1),
            model=model_cfg,
            input=DummyInput.default_config(),
            learner=learner.Learner.default_config().set(
                optimizer=config_for_function(optimizers.sgd_optimizer).set(
                    learning_rate=0.1, decouple_weight_decay=True
                ),
            ),
            max_step=8,
            checkpointer=Checkpointer.default_config().set(
                save_policy=config_for_function(every_n_steps_and_last_policy).set(
                    n=3,
                    max_step=8,
                ),
            ),
        )

        # Run trainer.
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        trainer.run(prng_key=jax.random.PRNGKey(123))

        assert os.path.exists(os.path.join(cfg.dir, "trainer_state_tree.txt"))
        trainer2: SpmdTrainer = cfg.instantiate(parent=None)
        with trainer2.mesh():
            # We should have checkpointed at the last step.
            self.assertEqual(8, trainer2.restore_checkpoint())

    def test_composite_learner(self):
        """Tests composite learner with two sub learners for weight/bias respectively."""
        cfg = SpmdTrainer.default_config().set(name="test_trainer")
        cfg.mesh_axis_names = ("data", "model")
        cfg.mesh_shape = (1, 1)
        cfg.dir = tempfile.mkdtemp()
        cfg.model = DummyModel.default_config().set(dtype=jnp.float32)
        cfg.input = DummyInput.default_config()
        opt1_cfg = config_for_function(optimizers.sgd_optimizer).set(
            learning_rate=0.1,
            decouple_weight_decay=True,
            momentum=0.9,
            weight_decay=0,
        )
        opt2_cfg = config_for_function(optimizers.adamw_optimizer).set(
            learning_rate=1.0, b1=0.9, b2=0.95, eps=1e-6
        )
        learner_rules = [(".*weight.*", "weight"), (".*bias.*", "bias")]

        cfg.learner = learner.CompositeLearner.default_config().set(
            rules=learner_rules,
            learners={
                "weight": learner.Learner.default_config().set(optimizer=opt1_cfg),
                "bias": learner.Learner.default_config().set(optimizer=opt2_cfg),
            },
        )
        evaler_cfg = SpmdEvaler.default_config().set(
            input=DummyInput.default_config().set(total_num_batches=2),
        )
        evaler_cfg.summary_writer.vlog = 5
        cfg.evalers = dict(eval_dummy=evaler_cfg)
        cfg.checkpointer.save_policy = config_for_function(every_n_steps_policy).set(n=5)
        cfg.summary_writer.vlog = 5
        cfg.max_step = 12
        trainer: SpmdTrainer = cfg.instantiate(parent=None)
        with trainer.mesh():
            trainer.init(prng_key=jax.random.PRNGKey(123))
            init_params = trainer.trainer_state.model
            trainer.run(prng_key=jax.random.PRNGKey(123))
            updated_params = trainer.trainer_state.model
            for (path, init_p), (_, updated_p) in zip(
                flatten_items(init_params), flatten_items(updated_params)
            ):
                self.assertGreater(np.max(np.abs(updated_p - init_p)), 1e-3, msg=path)


class SelectMeshConfigTest(test_utils.TestCase):
    def test_select_mesh_config(self):
        cfg = SpmdTrainer.default_config()
        self.assertIs(cfg.mesh_shape, REQUIRED)

        # When mesh_rules=None.
        self.assertIsNone(cfg.mesh_rules)
        select_mesh_config(cfg, mesh_selector="tpu-v4-128")
        # cfg.mesh_shape remains unchanged.
        self.assertIs(cfg.mesh_shape, REQUIRED)

        # When no mesh rule matches the selector.
        cfg.mesh_rules = (("tpu-v4-64", (4, 1, 8, 1)),)
        select_mesh_config(cfg, mesh_selector="tpu-v4-128")
        # cfg.mesh_shape still remains unchanged.
        self.assertIs(cfg.mesh_shape, REQUIRED)

        # When there is a match.
        select_mesh_config(cfg, mesh_selector="tpu-v4-64")
        # cfg.mesh_shape is overridden.
        self.assertEqual(cfg.mesh_shape, (4, 1, 8, 1))

        # When there is a match.
        cfg.mesh_rules = (
            ("gpu-(p5.48xlarge|p4de.24xlarge)-32", (4, 1, 8, 1)),
            ("gpu.*", None),
        )
        select_mesh_config(cfg, mesh_selector="gpu-p5.48xlarge-32")
        self.assertEqual(cfg.mesh_shape, (4, 1, 8, 1))
        select_mesh_config(cfg, mesh_selector="gpu-p4d.24xlarge-128")
        self.assertIsNone(cfg.mesh_shape)


class CompatibilityTest(test_utils.TestCase):
    def test_chex_serialization_compatibility(self):
        """Tests that a chex.dataclass that has been serialized as part of an AXLearn checkpoint
        can be read back in as a struct.PyTreeNode.
        """

        class Model(BaseModel):
            """Model that has struct params for testing."""

            @config_class
            class Config(BaseModel.Config):
                kind: Required[Literal["chex", "struct"]] = REQUIRED

            def initialize_parameters_recursively(
                self, prng_key: Tensor, *, prebuilt: Optional[NestedTensor] = None
            ) -> NestedTensor:
                del prng_key
                del prebuilt
                cfg = self.config
                if cfg.kind == "chex":
                    param = struct_test.Chex(
                        field_d=jnp.array(0),
                        field_b=jnp.array(1),
                        field_a=jnp.array(2),
                        field_c=jnp.array(3),
                    )
                elif cfg.kind == "struct":
                    param = struct_test.Struct(
                        field_d=jnp.array(5),
                        field_b=jnp.array(6),
                        field_a=jnp.array(7),
                        field_c=jnp.array(8),
                    )
                else:
                    raise NotImplementedError
                return {"param": param}

            def create_parameter_specs_recursively(self) -> NestedParameterSpec:
                shape_dtype = jax.eval_shape(
                    lambda: self.initialize_parameters_recursively(jax.random.PRNGKey(0))
                )
                return jax.tree_util.tree_map(
                    lambda x: ParameterSpec(shape=x.shape, dtype=x.dtype), shape_dtype
                )

        with tempfile.TemporaryDirectory() as tempdir:
            trainer_cfg = SpmdTrainer.default_config().set(
                name="tmp",
                dir=tempdir,
                model=Model.default_config().set(dtype=jnp.float32),
                input=DummyInput.default_config(),
                learner=learner.Learner.default_config().set(
                    optimizer=config_for_function(optimizers.sgd_optimizer).set(
                        learning_rate=0.1, decouple_weight_decay=True
                    )
                ),
                mesh_axis_names=("data",),
                mesh_shape=(1,),
            )
            trainer_cfg.checkpointer.save_policy = config_for_function(
                lambda: lambda *args, **kwargs: True
            )

            chex_trainer_cfg = trainer_cfg.clone()
            chex_trainer_cfg.model.kind = "chex"
            chex_trainer = chex_trainer_cfg.instantiate(parent=None)
            chex_trainer.init(prng_key=jax.random.PRNGKey(0))
            # pylint: disable-next=protected-access
            chex_trainer._step = 0
            chex_trainer.save_checkpoint({})
            chex_data = chex_trainer.trainer_state.model["param"]

            struct_trainer_cfg = trainer_cfg.clone()
            struct_trainer_cfg.model.kind = "struct"
            struct_trainer = struct_trainer_cfg.instantiate(parent=None)
            struct_trainer.init(prng_key=jax.random.PRNGKey(0))
            # Avoid unrelated errors about a prng key mismatch and input iterator mismatch.
            with unittest.mock.patch("axlearn.common.checkpointer.check_state_structure"):
                struct_trainer.restore_checkpoint()
            struct_data = struct_trainer.trainer_state.model["param"]

            self.assertIsInstance(chex_data, struct_test.Chex)
            self.assertIsInstance(struct_data, struct_test.Struct)
            chex.assert_trees_all_equal(
                dataclasses.asdict(chex_data), dataclasses.asdict(struct_data)
            )


if __name__ == "__main__":
    absltest.main()
